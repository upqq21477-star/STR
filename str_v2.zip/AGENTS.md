# AGENTS.md
> Codex 系統協定入口 | 版本：v2.1 | 對齊 log-entry.schema.json SCHEMA v2.3
> v2.1 變更：CONFIDENCE POLICY 改寫、VERSION 表清理、project-registry.json 補入 l0 欄位

---

## SYSTEM PURPOSE

這是一個語意編排系統。在**手機對話模式**下，Claude 作為 pipeline 執行者，
透過上傳包讀取狀態、處理後輸出完整新檔供下載。

```
上傳包（使用者提供）→ Claude 執行 COMPILE / SUMMARIZE / REVERSE / DISCUSS → 下載包（使用者取走）
```

| 角色 | 說明 |
|------|------|
| `project-registry.json` | 唯一狀態來源：專案 tags + id_index（L5 節點索引） |
| `AGENTS.md` | Claude 行為協定（本文件） |
| `tags.json` | 通用語意標籤基底層 |
| 當次工作文件 | 對話中要處理的 MD / 文字內容 |

---

## 手機對話模式操作說明

### 每次對話開始

上傳以下三個核心檔案，加上當次工作文件：

```
上傳包：
  project-registry.json   ← 必上傳（Claude 的唯一狀態來源）
  AGENTS.md               ← 必上傳（本協定）
  tags.json               ← 必上傳（語意基底層）
  [當次工作文件]          ← 視需要上傳（MD、文字等）
```

### 對話中

使用以下指令驅動 Claude：

| 指令 | 說明 |
|------|------|
| `COMPILE` | 記錄本次對話，輸出 entries[] + 新版 project-registry.json |
| `SUMMARIZE` | 輸出壓縮前情摘要，貼進下次對話開頭 |
| `REVERSE` | 對上傳的 MD 執行分層，輸出 L0~L5 結構 + 新版 project-registry.json |
| `DISCUSS` | 多輪問答，結束後切換 COMPILE 輸出 |
| `刪除 [id]` | 從 id_index 移除該節點，輸出新版 project-registry.json |

### 每次對話結束

下載以下檔案，覆蓋手機本地舊版：

```
下載包：
  project-registry.json   ← 必下載（覆蓋舊版）
  session-log-[日期].json ← 可選（本次 entries 存檔）
```

> ⚠️ 不需要手動合併 diff，不需要建立資料夾，Claude 輸出完整新檔。

---

## MODE DEFINITIONS

### COMPILE 模式（記錄對話內容）

觸發：對話結束，說「COMPILE」。

```
輸出區塊 1：SESSION_SUMMARY
  本輪對話的重點摘要（自由文字）

輸出區塊 2：ENTRIES
  Log JSON 格式的條目清單

輸出區塊 3：REGISTRY
  完整新版 project-registry.json（直接覆蓋，非 diff）
```

嚴格輸出格式（每次 COMPILE 必須遵守此結構，不得偏離）：

```
<SESSION_SUMMARY>
...摘要文字...
</SESSION_SUMMARY>

<ENTRIES>
[
  { ...log-entry 格式... }
]
</ENTRIES>

<REGISTRY>
{ ...完整 project-registry.json... }
</REGISTRY>
```

下載包：
  - project-registry.json（從 REGISTRY 區塊複製，直接覆蓋）
  - session-log-[日期].json（從 ENTRIES 區塊複製，可選下載）

### SUMMARIZE 模式（壓縮前情）

觸發：對話即將超出上下文，或主動說「SUMMARIZE」。

```
輸出：prior_summary_next 壓縮摘要文字
      （複製後貼進下次對話開頭即可）
```

### REVERSE 模式（文件分層）

觸發：上傳 MD 文件後說「REVERSE」。

```
第一階段輸出：L0~L4 結構樹（等待人工確認）
第二階段輸出（確認後）：
  ├── L5 節點清單（含各節點欄位）
  └── project-registry.json（含所有新 L5 的 id_index，完整新版）
```

### DISCUSS 模式（多輪討論）

觸發：說「DISCUSS」開始討論。

```
對話中：多輪問答，不輸出 entries

開始 DISCUSS 時：
  1. 識別本輪主題涉及的 tags（來自 project-registry.json 或 tags.json）
  2. 查看這些 tags 的 direction 欄位，帶入對應解題策略：
       heuristic_search  → 優先找瓶頸，再考慮重構
       modularization    → 優先考慮拆分責任邊界
       bruteforce        → 直接實作，效能問題事後再優化
       rollback          → 評估移除或回退選項
  3. 若主題 tags 無 direction（null），不強制套用策略，正常討論

結束時：discussion_summary（釐清結論）
        → 使用者說「結束討論」後自動切換 COMPILE 輸出
```

---

## PROJECT REGISTRY 規格

`project-registry.json` 是本系統在手機對話模式下的**唯一狀態來源**。

### 頂層欄位

| 欄位 | 說明 |
|------|------|
| `$version` | 檔案格式版本 |
| `$role` | 固定為 `"project_registry"` |
| `project_name` | 專案識別名稱（英文） |
| `display_name` | 顯示名稱（可含中文） |
| `updated_at` | ISO 8601 最後更新時間 |
| `tags` | 專案專有語意標籤層（不含 tags.json 通用標籤） |
| `id_index` | L5 節點索引：`{ "L5-001": { ...節點欄位 } }` |

### id_index 節點欄位

| 欄位 | 必填 | 說明 |
|------|------|------|
| `id` | ✓ | 節點 ID，格式 `L5-NNN` |
| `title` | ✓ | 節點標題 |
| `level` | ✓ | 固定為 `5` |
| `parent_id` | ✓ | 所屬 L4 節點 ID |
| `tags` | ✓ | 語意標籤陣列（來自 tags.json 或專案 tags） |
| `status` | ✓ | `pending` / `wip` / `done` / `blocked` |
| `summary` | ✓ | 節點內容摘要 |
| `code_ref` | — | 對應源碼函數或檔案（選填） |
| `supersedes` | — | 被此節點取代的舊節點 ID（選填） |
| `invalidates` | — | 此節點使哪些舊節點結論失效（選填，陣列）。與 supersedes 的區別：supersedes 是取代關係，invalidates 是「讓其結論不再成立」 |
| `reads` | — | 此節點讀取的共享可變狀態（選填，陣列）。例：["supplyBuf", "factionJoy"] |
| `writes` | — | 此節點寫入的共享可變狀態（選填，陣列）。例：["pressureBuf", "grainBuf"] |
| `version_introduced` | — | 引入此節點的版本號（選填） |
| `updated_at` | ✓ | ISO 8601 最後更新時間 |

> **關於 reads / writes**：這兩個欄位記錄的是**共享可變狀態**（shared mutable state），不是 module dependency。
> Legion3K 的核心共享狀態包括：`pressureBuf`、`supplyBuf`、`factionJoy`、`grainBuf`、`readBuf`/`writeBuf`、`diplomacyMatrix`、`provinceFactionPrestige`、`allianceState`、`cellCountCache`。
> devlog-node.schema.json 中有類似的 `affects[]` 欄位（自由文字），reads/writes 是其結構化版本。兩者共存，affects 保留用於自由描述，reads/writes 用於精確狀態追蹤。

### 新增與刪除節點

**新增**（Claude 自動處理）：
- 對話中產生新 L5 → 直接寫入輸出的 `project-registry.json`

**刪除**（觸發語句）：
- 「刪除 L5-005」→ Claude 從 `id_index` 移除後輸出新版 `project-registry.json`

---

## FORBIDDEN ACTIONS

- **禁止** 將 `project-registry.json` 以外的來源視為狀態依據
- **禁止** 輸出不完整的 `project-registry.json`（必須包含全部 `id_index` 條目）
- **禁止** 在 REVERSE 第一階段未經人工確認即輸出第二階段
- **禁止** 靜默修改節點的 `id`（移除舊節點、新增新節點，不得就地改 id）
- **禁止** 將 `partial`（DevLog 私有值）寫入 Log JSON 的 `decision` 欄位，必須轉換為 `pending`
- **禁止** 在 confidence < 0.85 時自動進入下一個輸出階段（必須先向使用者說明不確定點）

---

## PRIORITY ORDER

```
0. project registry   — project-registry.json 為唯一狀態來源，優先於一切
1. schema integrity   — devlog-node.schema.json 為外部工具接口，其欄位不可靜默擴充；
                        id_index 節點規格（定義於 AGENTS.md PROJECT REGISTRY 章節）
                        可在 AGENTS.md 版本升版時正式擴充
2. output completeness — 每次輸出的 project-registry.json 必須完整（非 diff）
3. traceability       — 節點變更須反映於 updated_at
4. modularity         — 每個模式（COMPILE / REVERSE 等）獨立可執行
5. extensibility      — 新專案切換不影響通用 AGENTS.md 與 tags.json
```

---

## CONFIDENCE POLICY

Claude 在每次輸出前自我評估信心度，並採取對應行動：

| 閾值 | 行動 |
|------|------|
| ≥ 0.85 | 直接輸出結果，繼續下一步 |
| 0.70–0.84 | 輸出結果，並附註「建議人工確認以下部分：…」後繼續 |
| 0.60–0.69 | 輸出結果，並明確列出不確定點，等待使用者確認再繼續 |
| < 0.60 | 停止輸出，說明缺乏足夠資訊的原因，請使用者補充後再進行 |

> 信心度適用於：REVERSE 第一階段的 block 分類、COMPILE 的 decision 標記、節點 tag 選取等有歧義的判斷。
> 純執行操作（刪除節點、格式轉換）不需評估信心度。

---

## STATE FILES REFERENCE（手機對話模式）

| 檔案 | 方向 | 說明 |
|------|------|------|
| `project-registry.json` | 上傳 → 下載 | 唯一狀態來源；每次對話後下載覆蓋舊版 |
| `AGENTS.md` | 上傳 | 本協定；版本升級時更新 |
| `tags.json` | 上傳 | 通用語意基底層；很少更新 |
| `session-log-[日期].json` | 下載（可選） | 本次 COMPILE 輸出的 entries 存檔 |

> 舊版 `state/` 目錄下的 JSON 檔案（`export-semantic.json`、`aggregator-index.json` 等）
> 在手機對話模式下不適用，不需上傳也不需管理。

---

## SCHEMA REFERENCE

```
schemas/（Claude 內建知識，不需上傳）
├── devlog-node.schema.json      ← L5 節點欄位格式定義
└── devlog-bridge-spec.md        ← decision→status 映射規則
```

---

## DOCS REFERENCE

```
docs/（背景參考，需要時請 Claude 解釋即可，不需上傳）
├── devlog-bridge-spec.md        ← decision→status 映射規則
├── branch-structure.md          ← branch.level 語意定義（L1–L4）
└── node-status-mapping.md       ← _nodeStatus() 邏輯正式文件
```

---

## 換專案

1. 請 Claude 輸出新專案的空白 `project-registry.json`
2. 下載存到手機（與其他專案的 registry 分開命名存放）
3. 下次對話上傳新專案的 registry 即可切換
4. `tags.json` 與 `AGENTS.md` 兩個專案共用，不需換

---

## VERSION

| 項目 | 版本 |
|------|------|
| AGENTS.md | **v2.2** |
| devlog-node.schema.json | v1.0 |
| log-entry.schema.json | SCHEMA v2.3 |
| tags.json | v1.1 |
| 最後更新 | 2026-05-16 |

### v2.2 變更紀錄

| 變更項目 | 說明 |
|---------|------|
| COMPILE 輸出格式 | 改為嚴格 XML 區塊（SESSION_SUMMARY / ENTRIES / REGISTRY） |
| DISCUSS 模式 | 加入 tags.direction 啟發策略引用 |
| PRIORITY ORDER 第 1 條 | 明確區分 devlog-node.schema（外部工具接口）與 id_index 規格（可在 AGENTS.md 版本升版時擴充） |
| id_index 節點規格 | 新增選填欄位：reads、writes、invalidates；補充共享狀態清單與 affects[] 共存說明 |

### v2.1 變更紀錄

| 變更項目 | 說明 |
|---------|------|
| CONFIDENCE POLICY | 改寫：移除 mergeConfirm / _meta.warn / policy label，改為 Claude 對話行為描述 |
| FORBIDDEN ACTIONS | 移除 mergeConfirm 禁令，改為「confidence < 0.85 不自動進入下一步」 |
| VERSION 表 | 移除 DevLog / Aggregator / Compiler / Validator 遺留版本號 |

### v2.0 變更紀錄

| 變更項目 | 說明 |
|---------|------|
| PRIORITY ORDER 第 0 條 | 新增：project-registry.json 為唯一狀態來源 |
| 手機對話模式操作說明 | 新增章節：上傳包、指令、下載包完整說明 |
| MODE DEFINITIONS | 改制：FAST/DEEP → COMPILE/SUMMARIZE/REVERSE/DISCUSS |
| PROJECT REGISTRY 規格 | 新增章節：id_index 節點欄位定義 |
| STATE FILES REFERENCE | 重寫：移除 state/ 目錄引用，改為手機對話模式說明 |
| DOCS REFERENCE | 精簡：移除 compiler-modes.md、pipeline-flow.md |
| FORBIDDEN ACTIONS | 更新：新增 registry 完整性禁令，移除 state/ 相關禁令 |
