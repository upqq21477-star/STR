# DevLog Bridge Spec
> 版本：v1.1 | 對齊 DevLog v60 + Validator v6（SCHEMA v2.3）

## 說明

此文件定義 DevLog 與 Log JSON 之間的欄位映射規則。
當 DevLog 透過 `exportAll()` 或 `exportValidator()` 輸出 JSON，
Validator 驗證時以此文件為依據。

**對應 Schema：** `schemas/log-entry.schema.json`

---

## 1. Decision → Module Status 映射

DevLog 節點的 `decision` 欄位決定 Semantic Compiler 的 `module_status`。

| DevLog `decision` | 對應 `module_status` | 對應 Log JSON `decision` | 說明 |
|---|---|---|---|
| `adopted`  | `done`     | `adopted`  | 決策已採納，模組完成 |
| `partial`  | `fixing`   | `pending`  | 部分採納，仍在修正（私有值，對外轉換） |
| `rejected` | `building` | `rejected` | 被拒，回到重建階段 |
| `pending`  | `pending`  | `pending`  | 待決策 |
| （其他 / 未設定） | `init` | `pending` | 初始狀態 |

> ⚠️ `partial` 為 DevLog 私有值。`exportAll()` 輸出時**必須轉換為 `pending`**，
> 不可直接出現在 Log JSON 的 `decision` 欄位。

**來源：** DevLog v60 `_nodeStatus(n)` 函數邏輯 + `SCHEMA.devlog_compat.decision_map`

---

## 2. Log JSON `_meta.mode` 定義

| mode | 來源工具 | 說明 |
|---|---|---|
| `compile`          | Aggregator v10 | 對話轉 Log JSON |
| `summarize`        | Aggregator v10 | 既有 Log 彙整 |
| `reverse_analysis` | Aggregator v10 REVERSE 模式第一階段 | 分析 blocks |
| `init_structure`   | Aggregator v10 REVERSE 模式第二階段 | 建立 L0–L4 結構樹 |

**注意：**
- `reverse_analysis`：不需要 `entries` 欄位，只需 `blocks`（見 `schemas/reverse-analysis.schema.json`）
- `init_structure`：需要 `root` 節點（L0–L4 樹），Validator 路由至 `validateStructure()`

---

## 3. DevLog exportAll() 輸出格式

DevLog v60 `exportAll()` 輸出的 Semantic JSON（寫入 `state/export-semantic.json`）：

```json
{
  "_meta": {
    "source": "devlog-v60",
    "version": "1.0",
    "mode": "compile",
    "has_events": true,
    "confidence": 0.0,
    "data_completeness": "medium",
    "warn": []
  },
  "topic_id": "<branch.id>",
  "source_node": "<node.id>",
  "session_summary": "<手動填寫>",
  "prior_summary_next": "<手動填寫>",
  "entries": [ ... ]
}
```

**Tags 校驗：** `exportAll()` 輸出時只保留 TAG_REGISTRY 內的合法 tag，
非法 tag 以 `console.warn` 記錄供 Codex 審查。

---

## 4. mergeConfirm() 寫回格式

Semantic Compiler 完成後，`spec.final.writeback[]` 寫回 DevLog 的格式：

```json
{
  "writeback": [
    {
      "node_id":    "<node.id>",
      "module_id":  "<module.id>",
      "status":     "done | fixing | building",
      "confidence": 0.0,
      "output":     "<生成內容>"
    }
  ]
}
```

DevLog `mergeConfirm()` 讀取 `writeback[]` 陣列，
根據 `node_id` 匹配並更新 `_db.nodes` 的對應節點。

**前提條件：** `validation.pass === true` 且 `confidence ≥ 0.85`（`auto_proceed`）。
否則需等待人工確認後才能執行 mergeConfirm。

---

## 5. Node Status ↔ module_status 完整對照

| `_db.nodes[id].status` (DevLog 內部) | `module_status` (Semantic Compiler) | 說明 |
|---|---|---|
| `pending`  | `pending`  | 尚未開始 |
| `wip`      | `building` | 進行中 |
| `done`     | `done`     | 完成 |
| `blocked`  | `blocked`  | 被阻塞 |

詳細邏輯見 `docs/node-status-mapping.md`

---

## 6. 版本對照表

| Validator Schema | DevLog 版本 | 說明 |
|---|---|---|
| v2.3（2026-05-12） | v60 | 目前版本，decision_map 同上，Aggregator 升至 v10 |
| v2.3（2026-05-12） | v59 | 初始 v2.3 版 |
| v2.2（2026-05-11） | v58–v59 | 同上（無破壞性變更） |

---

## 8. devlog-node → id_index 欄位對照表

REVERSE 第二階段輸出 id_index 節點時，Claude 依以下對照表從 devlog-node 欄位映射至 id_index 欄位。

| devlog-node 欄位 | id_index 欄位 | 映射規則 |
|---|---|---|
| `id` | `id` | 直接對應（格式改為 L5-NNN） |
| `title` | `title` | 直接對應 |
| `tags[]` | `tags[]` | 直接對應（校驗是否在 tags.json 或專案 tags 內） |
| `status` | `status` | 直接對應（pending/wip/done/blocked） |
| `objective` + `result` | `summary` | 合併為一段摘要文字 |
| `branchId` | `parent_id` | branch ID → L4 節點 ID |
| `based_on_nodes[]` | `supersedes` | 若 based_on_nodes 語意為「取代」，映射至 supersedes |
| `affects[]` | `reads` / `writes` | affects 為自由文字，人工判斷後拆分為 reads / writes（無法自動映射時保留在 affects，不強制） |
| `updated_at` | `updated_at` | 直接對應 |
| `fingerprint` / `anchor` | — | id_index 不收錄（DevLog 內部欄位） |
| `humanNote` | — | COMPILE 時記錄於 session_summary，不寫入 id_index |
| `open_questions[]` | — | DISCUSS 模式帶入討論，不寫入 id_index |
| `fails[]` | — | 失敗記錄保留在 devlog-node，id_index 只存成功結論 |
| `images`, `files`, `metrics` | — | id_index 不收錄 |
| `code_ref`（自行填入） | `code_ref` | REVERSE 時若 action/result 提及具體函數，可手動填入 |
| （新增）| `reads` | 從 affects[] 或 action/result 文字提取，選填 |
| （新增）| `writes` | 從 affects[] 或 action/result 文字提取，選填 |
| （新增）| `invalidates` | 若 result 明確宣告哪些舊節點結論失效，選填 |

> **注意**：affects[] 是自由文字（適合 DISCUSS），reads/writes 是精確狀態名稱陣列（適合 COMPILE 追蹤）。
> REVERSE 時 Claude 優先從 action/result 文字中識別共享狀態名稱，填入 reads/writes。
> 若無法確定，優先不填，不得猜測。

## 9. 升版規則

- DevLog 新增 `decision` 枚舉值時，先更新此文件
- 同步更新 `schemas/log-entry.schema.json` 的 `devlog_compat.decision_map`
- 更新 `SCHEMA.version.schema_date`
- `validate-cli.js` 中的映射表同步更新
- 更新 AGENTS.md 的版本對照表
