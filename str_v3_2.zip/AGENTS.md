# AGENTS.md
> 版本：v3.2 | 對齊 log-entry.schema.json SCHEMA v2.3

---

## SYSTEM PURPOSE

這是一個語意編排系統。在**手機對話模式**下，Claude 作為 pipeline 執行者，
透過上傳包讀取狀態、處理後輸出完整新檔供下載。

```
上傳包（使用者提供）→ Claude 執行 COMPILE / SUMMARIZE / REVERSE / DISCUSS → 下載包（使用者取走）
```

### 雙層檔案架構

| 層級 | 檔案 | 職責 |
|------|------|------|
| L0 | `project-overview.json` | 跨系統索引、依賴圖、全域設計記憶 |
| L1 | `sys-[name].json` | 單一系統的 L5 節點（id_index）、設計記憶、狀態所有權 |
| 協定 | `AGENTS.md` | Claude 行為協定（本文件） |
| 語意 | `tags.json` | 通用語意標籤基底層 |

---

## 手機對話模式操作說明

### 上傳包：三種情境

**情境 A：針對單一系統作業（最常見）**
```
project-overview.json     ← 必上傳（L0 索引）
AGENTS.md                 ← 必上傳（本協定）
tags.json                 ← 必上傳（語意基底）
sys-[目標系統].json       ← 必上傳（本次作業的 L1 系統）
[當次工作文件]            ← 視需要（MD、文字等）
```

**情境 B：跨系統討論**
```
project-overview.json     ← 必上傳
AGENTS.md                 ← 必上傳
tags.json                 ← 必上傳
sys-[系統A].json          ← 相關 L1 系統（複數）
sys-[系統B].json
```

**情境 C：建立新專案**
```
project-overview.json     ← 空白模板，填入 project_name 等基本資訊
AGENTS.md                 ← 必上傳
tags.json                 ← 必上傳
sys-template.json         ← 複製並重命名為目標系統名稱
```

### 對話中指令

| 指令 | 說明 |
|------|------|
| `COMPILE` | 記錄本次對話，輸出 entries[] + 新版 L1 檔 + 同步 L0 |
| `SUMMARIZE` | 輸出壓縮前情摘要，貼進下次對話開頭 |
| `REVERSE` | 對上傳的 MD 執行分層，輸出 L0~L5 結構 + 新版 L1 檔 + 同步 L0 |
| `DISCUSS` | 多輪問答，結束後切換 COMPILE 輸出 |
| `刪除 [id]` | 從 id_index 移除該節點，輸出新版 L1 檔 + 同步 L0 |
| `新增系統 [名稱]` | 輸出新的空白 sys-[名稱].json + 更新 L0 systems 登記；新 L1 的 `derived_from_l0_write_count` 必須設為當前 L0 的 `write_count`（不得保留模板預設值 0）|

### 下載包

```
project-overview.json     ← 必下載（L0，覆蓋舊版）
sys-[作業系統].json       ← 必下載（L1，覆蓋舊版）
session-log-[日期].json   ← 可選（本次 entries 存檔）
```

> ⚠️ L0 與 L1 需**同時下載**覆蓋，否則 exports[] 與 id_index 會不同步。

---

## MODE DEFINITIONS

### COMPILE 模式（記錄對話內容）

觸發：對話結束，說「COMPILE」。

嚴格輸出格式（每次 COMPILE 必須遵守，不得偏離）：

```
<SESSION_SUMMARY>
...摘要文字...
</SESSION_SUMMARY>

<ENTRIES>
[
  { ...log-entry 格式... }
]
</ENTRIES>

<SYSTEM_REGISTRY>
{ ...完整新版 sys-[name].json... }
</SYSTEM_REGISTRY>

<PROJECT_OVERVIEW>
{ ...完整新版 project-overview.json（含更新的 exports[] 與 node_count）... }
</PROJECT_OVERVIEW>
```

> COMPILE 必須同時輸出 SYSTEM_REGISTRY 與 PROJECT_OVERVIEW 兩個區塊。
> 若本次對話未修改 id_index，PROJECT_OVERVIEW 只更新 updated_at。
> **每次 COMPILE：L0 `write_count` +1；L1 `write_count` +1；L1 `derived_from_l0_write_count` 更新為本次輸出後 L0 的 `write_count`。**

### SUMMARIZE 模式（壓縮前情）

觸發：對話即將超出上下文，或主動說「SUMMARIZE」。

```
輸出：prior_summary_next 壓縮摘要文字
      （複製後貼進下次對話開頭即可）
```

### REVERSE 模式（文件分層）

觸發：上傳 MD 文件後說「REVERSE」。

```
第一階段輸出：L0~L4 結構樹（等待人工確認）
第二階段輸出（確認後）：
  ├── L5 節點清單（含各節點欄位）
  ├── sys-[name].json（含所有新 L5 的 id_index，完整新版）
  └── project-overview.json（更新 exports[] 與 node_count）
```

### DISCUSS 模式（多輪討論）

觸發：說「DISCUSS」開始討論。

```
開始 DISCUSS 時：
  1. 識別本輪主題涉及的 tags（來自 sys-[name].json 的 owns_tags 或 tags.json）
  2. 查看這些 tags 的 direction 欄位，帶入對應解題策略：
       heuristic_search  → 優先找瓶頸，再考慮重構
       modularization    → 優先考慮拆分責任邊界
       bruteforce        → 直接實作，效能問題事後再優化
       rollback          → 評估移除或回退選項
  3. 若主題節點的 tags[] 含有 runtime_hints key，啟動對應保守策略：
       hot_path          → 任何建議必須先評估 allocation，禁止新增陣列建立
       O(N)-critical     → 明確說明複雜度，有疑慮時優先拒絕而非猜測
       fanout_high       → 修改前主動列出 chain 下游受影響系統
       write_heavy       → 建議前先確認 cache invalidation 影響範圍
  4. 若主題 tags 無 direction 且無 runtime_hints，不強制套用策略，正常討論

結束時：discussion_summary
        → 使用者說「結束討論」後自動切換 COMPILE 輸出
```

---

## RUNTIME HINTS 使用說明

`tags.json` 的 `runtime_hints` 是獨立命名空間，與 `tags` 分開。

**用法：** 直接將 runtime_hints 的 key 放入 L5 節點的 `tags[]` 陣列。

```json
{
  "id": "L5-007",
  "title": "supplyBuf BFS 波前傳播",
  "tags": ["核心邏輯", "效能", "hot_path", "O(N)-critical", "write_heavy"],
  "cross_state_refs": ["terrainBuf", "warZoneMap", "supplyBuf"],
  "reads":  ["terrainBuf", "warZoneMap"],
  "writes": ["supplyBuf"]
}
```

AI 看到 `hot_path` 就會自動約束建議範圍，不需要每次用自然語言重新說明限制。

**原則：** runtime_hints 描述「這段程式在 runtime 的行為特性」；`tags` 描述「這個節點的語意分類」。兩者可共存於同一個 `tags[]` 陣列，不衝突。

---

## PROJECT REGISTRY 規格

### L0：project-overview.json

| 欄位 | 說明 |
|------|------|
| `project_name` | 專案識別名稱（英文）|
| `display_name` | 顯示名稱（可含中文）|
| `l0` | 專案目標、技術棧、約束、跨系統設計記憶 |
| `systems` | 各 L1 系統的索引條目 |
| `cross_system_state` | 跨系統共享可變狀態的所有權與依賴鏈（produced_by / consumed_by / chain）|
| `write_count` | 整數，初始為 0；每次 COMPILE 自動 +1。版本連續性驗證的基準值 |

**systems 條目欄位：**

| 欄位 | 必填 | 說明 |
|------|------|------|
| `file` | ✓ | 對應的 L1 檔名 |
| `display_name` | ✓ | 顯示名稱 |
| `owns_tags` | ✓ | 本系統專有的語意標籤陣列 |
| `shared_state.reads` | ✓ | 讀取的共享可變狀態 |
| `shared_state.writes` | ✓ | 寫入的共享可變狀態 |
| `status` | ✓ | `pending` / `wip` / `done` / `blocked` |
| `node_count` | ✓ | 目前 id_index 節點數（每次 COMPILE 同步更新）|
| `exports` | ✓ | L5 節點淺層清單：`[{ "id", "title", "status" }]` |

### L1：sys-[name].json

| 欄位 | 說明 |
|------|------|
| `$system_id` | 系統識別名稱（對應 L0 systems 的 key）|
| `owns_tags` | 本系統專有語意標籤（不含 tags.json 通用標籤）|
| `shared_state` | 本系統的 reads / writes；含 `"$source": "derived_from_l0"` 標記，表示此欄為 L0 cross_system_state 的冗餘副本 |
| `design_memory` | 本系統的 anti_patterns 與 forbidden_directions |
| `id_index` | 本系統所有 L5 節點 |
| `write_count` | 整數，初始為 0；每次 COMPILE 自動 +1（與 L0 各自獨立遞增）|
| `derived_from_l0_write_count` | 本 L1 最後一次與 L0 同步時，L0 的 write_count 值；用於雙向版本對齊驗證 |

### id_index 節點欄位

| 欄位 | 必填 | 說明 |
|------|------|------|
| `id` | ✓ | 節點 ID，格式 `L5-NNN` |
| `title` | ✓ | 節點標題 |
| `level` | ✓ | 固定為 `5` |
| `parent_id` | ✓ | 所屬 L4 節點 ID |
| `tags` | ✓ | 語意標籤陣列（可引用 tags.json 的 tags 或 runtime_hints key）|
| `status` | ✓ | `pending` / `wip` / `done` / `blocked` |
| `summary` | ✓ | 節點內容摘要 |
| `updated_at` | ✓ | ISO 8601 最後更新時間 |
| `cross_state_refs` | ★ | 此節點涉及的所有共享狀態名稱（`reads ∪ writes` 的超集；涉及任何 cross_system_state 登記狀態時必填）|
| `reads` | ★ | 此節點讀取的共享可變狀態（必須為 `cross_state_refs` 的子集）|
| `writes` | ★ | 此節點寫入的共享可變狀態（必須為 `cross_state_refs` 的子集）|
| `code_ref` | — | 對應源碼函數或檔案（選填）|
| `supersedes` | — | 被此節點取代的舊節點 ID（選填）|
| `invalidates` | — | 此節點使哪些舊節點結論失效（選填，陣列）|
| `version_introduced` | — | 引入此節點的版本號（選填）|

> ★ 條件必填：節點 `summary` 或 `code_ref` 中涉及任何 `cross_system_state` 登記的狀態名稱時，`cross_state_refs` / `reads` / `writes` 必須填寫，不得留空。驗證邏輯：`reads ∪ writes ⊆ cross_state_refs`，違反即視為欄位錯誤。

---

## 分檔閾值規範

| 指標 | 軟上限（Claude 主動提示） | 硬上限（強制拆分）|
|------|------------------------|-----------------|
| L5 節點數 | 40 | 60 |
| 檔案行數（JSON 展開）| 500 | 800 |

**拆分流程：**
1. 將原 `sys-[name].json` 按子領域拆為 `sys-[name]-[sub].json`
2. 原檔降格為目錄頁，只保留 `sub_modules` 索引
3. L0 的 `systems.[name]` 改為 `{ "type": "split", "sub_modules": [...] }`

---

## FORBIDDEN ACTIONS

- **禁止** 將 `project-overview.json` 以外的來源視為跨系統狀態依據
- **禁止** 輸出不完整的 `sys-[name].json`（必須包含全部 `id_index` 條目）
- **禁止** 輸出不完整的 `project-overview.json`（必須包含全部 `systems` 條目）
- **禁止** 僅輸出 L1 系統檔而不同步更新 L0 的 `exports[]`（除非明確說「只更新 L1」）
- **禁止** 在 REVERSE 第一階段未經人工確認即輸出第二階段
- **禁止** 靜默修改節點的 `id`（移除舊節點、新增新節點，不得就地改 id）
- **禁止** 將 `partial`（DevLog 私有值）寫入 Log JSON 的 `decision` 欄位，必須轉換為 `pending`
- **禁止** 在 confidence < 0.85 時自動進入下一個輸出階段（必須先向使用者說明不確定點）
- **禁止** 輸出涉及 `cross_system_state` 狀態的 L5 節點而不填 `cross_state_refs`（節點 summary 或 code_ref 提及登記狀態名稱即觸發此規則；`reads` / `writes` 必須為 `cross_state_refs` 的子集）
- **禁止** 在 L0 缺失的情況下修改 L1 的 `shared_state`（L0 缺失時，L1 `shared_state` 視為 read-only；若需修改，必須先要求使用者補上傳 L0）
- **禁止** 在版本完整性前置檢查判定為「強制停止」的情況下繼續輸出（僅適用於 CONFIDENCE POLICY 中標記為**強制停止**的兩種情境：L1 derived_from_l0_write_count > L0 write_count，或 write_count 內部邏輯矛盾；降至 0.70 tier 的情境仍可繼續輸出，附帶警告即可）

---

## PRIORITY ORDER

```
0. project overview   — project-overview.json 為跨系統唯一狀態來源
1. system registry    — sys-[name].json 為各系統唯一節點來源
2. schema integrity   — devlog-node.schema.json 為外部工具接口，欄位不可靜默擴充
3. output completeness — 每次輸出的 JSON 必須完整（非 diff），L0 與 L1 必須同步輸出
4. traceability       — 節點變更須反映於 updated_at
5. modularity         — 每個模式（COMPILE / REVERSE 等）獨立可執行
6. extensibility      — 新系統新增只需建立 sys-[name].json 並在 L0 登記
```

---

## CONFIDENCE POLICY

> **版本完整性前置檢查（優先於所有閾值判斷，每次對話讀入檔案後立即執行）**

| 狀況 | 行動 |
|------|------|
| L1 `write_count` < L1 `derived_from_l0_write_count` | **強制停止**，說明「L1 write_count 小於 derived_from_l0_write_count，檔案可能遭手動修改或版本混淆」，要求使用者確認後才繼續 |
| L1 `derived_from_l0_write_count` > L0 `write_count` | **強制停止**，說明「L1 比 L0 新，可能是 L0 未覆蓋舊版」，要求使用者確認後才繼續 |
| L0 `write_count` > L1 `derived_from_l0_write_count` + 3 | 降至 0.70 tier，提示「L1 可能落後 L0 超過 3 版，建議確認是否遺漏同步」 |
| L0 缺失（未上傳） | 降至 0.70 tier，標記 L1 `shared_state` 為 read-only，禁止跨系統修改 |

> 前置檢查通過後，依下表執行閾值判斷：

| 閾值 | 行動 |
|------|------|
| ≥ 0.85 | 直接輸出結果，繼續下一步 |
| 0.70–0.84 | 輸出結果，附註「建議人工確認以下部分：…」後繼續 |
| 0.60–0.69 | 輸出結果，明確列出不確定點，等待使用者確認再繼續 |
| < 0.60 | 停止輸出，說明缺乏足夠資訊的原因，請使用者補充後再進行 |

---

## STATE FILES REFERENCE

| 檔案 | 方向 | 說明 |
|------|------|------|
| `project-overview.json` | 上傳 → 下載 | L0 跨系統索引；每次對話後下載覆蓋舊版 |
| `sys-[name].json` | 上傳 → 下載 | L1 系統 registry；每次對話後下載覆蓋舊版 |
| `AGENTS.md` | 上傳 | 本協定；版本升級時更新 |
| `tags.json` | 上傳 | 通用語意基底層；很少更新 |
| `sys-template.json` | 參考 | 新系統建立時複製使用；不需每次上傳 |
| `session-log-[日期].json` | 下載（可選）| 本次 COMPILE 輸出的 entries 存檔 |

---

## 換專案

1. 請 Claude 輸出新專案的空白 `project-overview.json`（填入 project_name 等）
2. 為每個系統複製 `sys-template.json`，重命名為 `sys-[name].json`
3. 在 `project-overview.json` 的 `systems` 登記各系統條目
4. `tags.json` 與 `AGENTS.md` 跨專案共用，不需更換

---

## SCHEMA REFERENCE

```
schemas/（Claude 內建知識，不需上傳）
├── devlog-node.schema.json          ← L5 節點欄位格式定義
├── log-entry.schema.json            ← COMPILE entries 格式定義
├── reverse-analysis.schema.json     ← REVERSE 第一階段輸出格式
└── devlog-bridge-spec.md            ← decision→status 映射規則
```

---

## VERSION

| 項目 | 版本 |
|------|------|
| AGENTS.md | **v3.2** |
| devlog-node.schema.json | v1.0 |
| log-entry.schema.json | SCHEMA v2.3 |
| tags.json | v1.3 |
| 最後更新 | 2026-05-16 |

### v3.2 變更紀錄

| 變更項目 | 說明 |
|---------|------|
| cross_state_refs | 新增 L5 節點條件必填欄位；reads ∪ writes 必須為其子集；取代原先依賴 AI 推理 summary 文字的隱式驗證 |
| write_count | L0 / L1 各自新增 write_count 整數欄位；每次 COMPILE 自動 +1 |
| derived_from_l0_write_count | L1 新增欄位；記錄最後一次同步時 L0 的 write_count；支援雙向版本對齊驗證 |
| shared_state $source | L1 shared_state 新增 `"$source": "derived_from_l0"` 標記，明確標示為冗餘副本而非獨立權威值 |
| CONFIDENCE POLICY | 新增版本完整性前置檢查：L1.write_count < L1.derived_from_l0_write_count（內部矛盾）→ 強制停止；L1.derived_from_l0_write_count > L0.write_count（L1 超前 L0）→ 強制停止；L0.write_count 超前 L1 超過 3 版 → 0.70 tier 警告繼續；L0 缺失 → 0.70 tier，L1 shared_state read-only |
| FORBIDDEN ACTIONS | 第9條改為引用 cross_state_refs；新增第10條（L0 缺失時 L1 shared_state read-only）；新增第11條（前置檢查未通過禁止繼續輸出）|
| cross_system_state chain | chain 條目從字串升格為 `{ "state", "phase" }` 物件，支援 temporal ordering 推理 |
| tags.json | 升至 v1.3，runtime_hints 新增硬上限規則（上限 12 個 key）|

### v3.1 變更紀錄

| 變更項目 | 說明 |
|---------|------|
| runtime_hints | 新增章節說明 runtime_hints 用法與與 tags 的命名空間分離 |
| reads / writes | 從選填改為條件必填（涉及 cross_system_state 狀態時強制填寫）|
| FORBIDDEN ACTIONS | 新增第 9 條：涉及共享狀態的節點必填 reads / writes |
| DISCUSS 模式 | 加入 runtime_hints 的保守策略觸發規則 |
| cross_system_state | 欄位說明更新，反映新增的 chain 欄位 |
| tags.json | 對齊 v1.2（新增 runtime_hints 區塊）|

### v3.0 變更紀錄

| 變更項目 | 說明 |
|---------|------|
| 雙層架構 | 引入 L0（project-overview.json）+ L1（sys-[name].json）分離 |
| COMPILE 輸出 | 新增 SYSTEM_REGISTRY + PROJECT_OVERVIEW 雙區塊強制同步輸出 |
| 上傳協定 | 新增三情境說明（單系統 / 跨系統 / 新專案建立）|
| FORBIDDEN ACTIONS | 新增「禁止只更新 L1 不同步 L0 exports[]」|
| PRIORITY ORDER | 重寫以反映 L0/L1 雙層優先順序 |
| 通用化 | 移除所有 Legion3K 專屬內容 |
| 分檔閾值 | 新增節點數閾值規範（40 警告 / 60 強制拆分）|
