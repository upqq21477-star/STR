# DevLog Bridge Spec
> 版本：v1.2 | 對齊 SCHEMA v2.3

## 說明

此文件定義 Log JSON 欄位映射規則，供 Claude 在 COMPILE 模式下輸出 entries 時參照。

> **注意（v1.2）：** `exportAll()`、`mergeConfirm()`、`Validator`、`state/` 目錄等工具
> 屬於舊版 DevLog HTML 工具鏈的概念，在**手機對話模式下不使用**。
> 本文件保留相關章節作為格式參照，但不需要實際執行這些工具。

**對應 Schema：** `log-entry.schema.json`

---

## 1. Decision 欄位值規範

Log JSON `entries[].decision` 只允許三個值：

| `decision` 值 | 語意 | 說明 |
|---|---|---|
| `adopted`  | 決策已採納 | 此條目的結論已正式採用 |
| `rejected` | 決策被拒絕 | 此方向被明確否定 |
| `pending`  | 待決策 | 包含「部分採納」等中間狀態 |

> ⚠️ `partial` 為內部私有值，**必須轉換為 `pending`** 後才能寫入 entries。

---

## 2. Log JSON `_meta.mode` 定義

| mode | 說明 |
|---|---|
| `compile`          | COMPILE 模式：對話轉 Log JSON |
| `summarize`        | SUMMARIZE 模式：既有 Log 彙整 |
| `reverse_analysis` | REVERSE 第一階段：分析 blocks |
| `init_structure`   | REVERSE 第二階段：建立 L0–L4 結構樹 |

---

## 3. COMPILE 輸出的 entries 格式

```json
{
  "_meta": {
    "source": "claude-agents-v3",
    "version": "3.0",
    "mode": "compile",
    "has_events": false,
    "confidence": 0.9,
    "data_completeness": "high",
    "warn": []
  },
  "topic_id": "<系統 id，例：combat>",
  "source_node": "<相關 L5 節點 id，若無則為空字串>",
  "session_summary": "<本輪對話摘要>",
  "prior_summary_next": "<供下次對話使用的前情摘要>",
  "entries": [
    {
      "id": "<唯一識別碼>",
      "objective": "<此條目目標>",
      "action": "<執行動作>",
      "result": "<執行結果>",
      "decision": "adopted | rejected | pending",
      "impact": {
        "level": "low | medium | high",
        "scope": ["architecture | module | local"]
      },
      "change_summary": "<變更摘要（最少 10 字）>",
      "change_type": "feature | fix | refactor | config | doc | test | remove | none",
      "ts": "<ISO 8601 或 null>"
    }
  ]
}
```

---

## 4. Node Status ↔ module_status 對照

| 節點 `status`（L1 id_index）| `module_status`（語意）| 說明 |
|---|---|---|
| `pending`  | `pending`  | 尚未開始 |
| `wip`      | `building` | 進行中 |
| `done`     | `done`     | 完成 |
| `blocked`  | `blocked`  | 被阻塞 |

---

## 5. devlog-node → id_index 欄位映射

REVERSE 第二階段輸出 id_index 節點時，依以下對照表映射：

| 來源欄位 | id_index 欄位 | 映射規則 |
|---|---|---|
| `id` | `id` | 格式改為 L5-NNN |
| `title` | `title` | 直接對應 |
| `tags[]` | `tags[]` | 校驗是否在 tags.json 或 owns_tags 內 |
| `status` | `status` | 直接對應 |
| `objective` + `result` | `summary` | 合併為一段摘要 |
| `branchId` | `parent_id` | branch ID → L4 節點 ID |
| `based_on_nodes[]` | `supersedes` | 若語意為「取代」，映射至 supersedes |
| `affects[]` | `reads` / `writes` | 自由文字，人工判斷後拆分 |
| `updated_at` | `updated_at` | 直接對應 |
| `fingerprint`, `anchor`, `humanNote`, `open_questions[]`, `fails[]` | — | id_index 不收錄 |

---

## 6. 版本對照

| Schema 版本 | 日期 | 說明 |
|---|---|---|
| v2.3 | 2026-05-12 | 目前版本 |
| v1.2（本文件）| 2026-05-16 | 移除 DevLog 工具鏈依賴，對齊 AGENTS.md v3.0 |
