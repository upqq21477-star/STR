# STR v4.5 Quick Start

## 檔案清單

### 協定層（AGENTS）
| 檔案 | 說明 |
|------|------|
| `AGENTS-axioms.md` | 核心不變原則（v4.5：含 A9 scope freeze）|
| `AGENTS-protocol.md` | Claude 行為協定（v4.5：含 BUILD/EXECUTE/Commander/Worker 模式）|
| `AGENTS-workflow.md` | 工作流與情境說明（v4.5：含 D1/D2/E 情境）|
| `AGENTS-changelog.md` | 版本記錄 |

### 工具鏈
| 檔案 | 說明 |
|------|------|
| `compile.js` | 主編譯器。驗證 + cycle detection + bundle + --extract + --validate-contract（v4.5）|
| `generate_uid.js` | uid 生成工具（AI 唯一合法 uid 來源）|
| `migrate_v3_to_v4.js` | v3.2 → v4.0 遷移腳本 |

### Schema 層
| 檔案 | 說明 |
|------|------|
| `devlog-node.schema.json` | L5 節點格式定義 v2.0（v4.5：含 code_spec 欄位；uid 描述修正為 v4.3：16位）|
| `devlog-node.schema.md` | 同上，人類閱讀版 |
| `execution-contract.schema.json` | execution_contract 格式規範（v4.5 新增）|
| `execution-contract.schema.md` | 同上，含範例、Worker 輸出格式、缺口四文件化 |
| `code-spec.schema.md` | Code Spec Layer 格式規範（v4.5 新增）|
| `constraint-vocab.md` | Constraint 標準詞彙表 v0.1（v4.5 新增；P0-lite）|
| `log-entry.schema.md` | Log entry 格式規範 |

### Source 層（L0 / L1）
| 檔案 | 說明 |
|------|------|
| `project-overview.json` | L0：跨系統索引 |
| `sys-l3k-arch.json` | L1：Edge registry + governance（v4.5：schema_version 4.4）|
| `sys-l3k-ui.json` | L1：UI / 渲染系統 |
| `sys-l3k-diplomacy.json` | L1：外交 / 戰役層 |
| `sys-l3k-ref.json` | L1：參考 / 公式層 |
| `sys-l3k-cognition.json` | L1：認知 / 啟發層 |
| `sys-template.json` | L1 空白模板（新系統建立時複製）|
| `symbol-table.json` | uid identity + tombstone source of truth（v4.5：唯一 tombstone 來源）|
| `id_index.json` | uid 總攬表（generated projection；v4.5：不含 tombstones 區塊）|

---

## 全新專案流程

```bash
# 1. 複製並填寫 L0
cp project-overview.json my-project-overview.json
# 填入 project_name、display_name、root_code（2~5 大寫字母，不可更改）

# 2. 建立第一個 L1 系統
cp sys-template.json sys-myproject-core.json
# 填入 $system_id、display_name

# 3. 為每個節點生成 uid
node generate_uid.js 10   # 一次產生 10 個備用

# 4. 填寫節點後，執行第一次 compile
node compile.js --validate-only   # 先只驗證
node compile.js                   # 正式編譯

# 5. 確認 COMPILE_REPORT.json status = "ok"
# 6. 上傳 compiled_graph.bundle.json + AGENTS-axioms.md + AGENTS-protocol.md 開始對話
```

---

## 每次 Claude 對話流程（情境 A/B）

```
對話前：
  node compile.js
  確認 COMPILE_REPORT.json status = "ok"
  上傳 compiled_graph.bundle.json + AGENTS-axioms.md + AGENTS-protocol.md
       + [目標 sys-*.json（若需輸出新版）]

對話後：
  下載 sys-[name].json + project-overview.json
  覆蓋本機舊版
  node compile.js   ← 必須重新 compile，才能進行下一次對話
```

---

## 實作流程（情境 D1 → D2 → E）

```
1. Commander session 前準備：
   node compile.js --extract [display_id]
   → 產出 build_slice_[display_id].json

2. 情境 D1（指揮官 session）：
   上傳：build_slice_[id].json + AGENTS-axioms.md + AGENTS-protocol.md
         + code-[domain].md + COMPILE_REPORT.json（建議）
   說：BUILD [display_id]
   → 輸出：execution_contract_[display_id].json

3. Contract 驗證：
   node compile.js --validate-contract execution_contract_[id].json
   → 必須通過，才進 D2

4. 情境 D2（Worker session）：
   上傳：execution_contract_[display_id].json（唯一檔案）
   說：EXECUTE
   → 輸出：代碼（含 @node 標頭 + CHECKLIST）

5. 情境 E（驗收）：
   上傳：execution_contract_[id].json + 代碼檔案
   說：BUILD [display_id] --verify
   → VERIFY PASS 後更新 sys-*.json（code_ref / validation / status）
```

---

## 對話中指令

| 指令 | 說明 |
|------|------|
| `COMPILE` | 記錄本次對話，輸出 entries[] + 新版 L1 + 同步 L0 |
| `SUMMARIZE` | 輸出壓縮前情摘要 |
| `REVERSE` | 對上傳 MD 執行分層，輸出 L0~L5 + L1 + code-*.md 骨架（v4.5）|
| `DISCUSS` | 多輪問答 |
| `BUILD [display_id]` | 開啟指揮官 session，產出 execution_contract |
| `BUILD [display_id] --verify` | 驗收 Worker 產出的代碼 |
| `BUILD [display_id] --spec` | 只輸出規格摘要 |
| `EXECUTE` | 開啟 Worker session，讀取 contract 產出代碼 |
| `REGENERATE_INDEX` | 重建 id_index.json |

---

## compile.js 選項

| 選項 | 說明 |
|------|------|
| `node compile.js` | 完整編譯 |
| `node compile.js --validate-only` | 僅驗證，不寫入 |
| `node compile.js --bundle-only` | 輸出 bundle，不更新 id_index |
| `node compile.js --extract [display_id]` | 產出 build_slice_[id].json（D1 前執行）|
| `node compile.js --validate-contract [file]` | 驗證 execution_contract 純淨性（D1 後執行）|
| `node compile.js --dir [path]` | 指定專案目錄 |

---

## 從 v3.2 遷移

```bash
node migrate_v3_to_v4.js --dry-run   # 預覽
node migrate_v3_to_v4.js             # 執行（自動備份為 .v32-backup-*.json）
# 人工審查 migration_log.json 中 _review_required: true 的節點
node compile.js --validate-only
node compile.js
```

---

## uid 使用規則

```bash
node generate_uid.js               # 產生新 uid（16位 hex，v4.3+）
node generate_uid.js 5             # 批次產生 5 個
node generate_uid.js --check <uid> # 驗證格式（接受 12位 legacy 或 16位）
```

**禁止：** AI 不得自行生成 uid；廢棄節點 uid 進入 tombstone 後永不再使用。

---

## 版本

| 項目 | 版本 |
|------|------|
| README.md | **v4.5** |
| 最後更新 | 2026-05-18 |
